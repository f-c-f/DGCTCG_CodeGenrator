#pragma once
#include <string>
#include <vector>

using namespace std;

std::string processStruct(std::string str);

std::string getWord(std::string& code);

void listFiles(string dir, vector<string> &fileList, string format);

string readFileOri(string path);

string removeCodeIfdef(string code);

string removeStructMemberTypeConst(string code);