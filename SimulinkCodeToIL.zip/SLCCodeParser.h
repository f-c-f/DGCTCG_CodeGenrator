#pragma once


#include <string>
#include <vector>
#include <iostream>
#include <map>
#include <clang-c/Index.h>

using namespace std;


class SLCCodeParser
{
public:

    vector<string> functions;

    int parse(string filePath);
};