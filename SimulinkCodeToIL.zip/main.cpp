#include <iostream>
#include "util.h"

#include "../../Src/Common/Utility.h"
#include "../../Src/ILBasic/ILParser.h"
#include "../../Src/ILBasic/ILSaver.h"
#include "../../Src/ILBasic/ILInput.h"
#include "../../Src/ILBasic/ILOutput.h"
#include "../../Src/ILBasic/ILExternVariable.h"
#include "../../Src/ILBasic/ILFile.h"
#include "../../Src/ILBasic/ILMacro.h"
#include "../../Src/ILBasic/ILStructDefine.h"
#include "../../Src/ILBasic/ILMember.h"
#include "../../Src/ILBasic/ILTypeDefine.h"
#include "../../Src/ILBasic/ILFunction.h"
#include "../../Src/ILBasic/ILSchedule.h"
#include "../../Src/ILBasic/ILCalculate.h"
#include "../../Src/ILBasic/ILGlobalVariable.h"
#include "../../Src/ILBasic/ILHeadFile.h"
#include "../../Src/ILBasic/ILRef.h"
#include "..\..\Src\ILBasic\ILExpressionParser.h"
#include "..\..\Src\ILBasic\Expression.h"
#include "SLCCodeParser.h"

using namespace std;


string modelName = "regs_12B";



int parseFunctionCodeToIL(string functionHead, string functionBody, ILFunction* iLFunction)
{
    string functionHeadTemp = functionHead;

    string wordRetType = getWord(functionHeadTemp);
    if(wordRetType == "static")
        wordRetType = getWord(functionHeadTemp);

    bool isAddressRet = false;
    string wordFuncName = getWord(functionHeadTemp);
    if(wordFuncName == "*")
    {
        isAddressRet = true;
        wordFuncName = getWord(functionHeadTemp);
    }
    iLFunction->name = wordFuncName;
    iLFunction->returnType = wordRetType;
    iLFunction->type = ILFunction::FunctionNormal;

    string wordParaType = getWord(functionHeadTemp); //����(

    wordParaType = getWord(functionHeadTemp);
    while(!wordParaType.empty() && wordParaType != ")")
    {
        if(wordParaType == "const")
        {
            wordParaType = getWord(functionHeadTemp);
        }
        bool isAddress = false;
        string wordParaName = getWord(functionHeadTemp);
        if(wordParaName == "*") {
            isAddress = true;
            wordParaName = getWord(functionHeadTemp);
            if(wordParaName == "const")
            {
                wordParaName = getWord(functionHeadTemp);
            }
        }

        
        vector<int> arraySize;

        string word = getWord(functionHeadTemp);
        while(word == "[")
        {
            word = getWord(functionHeadTemp);
            if(word == "]")
            { 
                arraySize.push_back(-1);
            }
            else
            {
                arraySize.push_back(stringToInt(word));
                word = getWord(functionHeadTemp);
            }
            word = getWord(functionHeadTemp);
        }


        ILInput* iLInput_p = new ILInput();
        iLInput_p->name = wordParaName;
        iLInput_p->type = wordParaType;
        iLInput_p->isAddress = isAddress;
        iLInput_p->arraySize = arraySize;
        iLFunction->inputs.push_back(iLInput_p);

        //wordParaType = getWord(functionHeadTemp);
        wordParaType = getWord(functionHeadTemp);
    }

    ILSchedule* iLSchedule = new ILSchedule();
    iLFunction->schedule = iLSchedule;

    
    Statement stmt;
    ILCCodeParser codeParser;
    int res = codeParser.parseCCode(functionBody, &stmt);
    if(res < 0)
    {
        return res;
    }

    ILCalculate* iLCalculate = new ILCalculate();
    iLCalculate->statements = stmt;
    iLCalculate->name = wordFuncName;

    iLSchedule->scheduleNodes.push_back(iLCalculate);

    return 1;
}


int parseOtherFileFunction(ILParser* iLParser, ILFile* iLFile, string functionStr)
{
    size_t pos = functionStr.find("{");
    if(pos == string::npos)
        return 0;
    string functionHead = functionStr.substr(0, pos);
    functionHead = codeRemoveComment(functionHead);
    string functionBody = functionStr.substr(pos + 1, functionStr.length() - pos - 2);
    functionBody = removeCodeIfdef(functionBody);
    functionBody = codeRemoveComment(functionBody);

    ILFunction* iLFunction = new ILFunction();
    iLFile->functions.push_back(iLFunction);

    int res = parseFunctionCodeToIL(functionHead, functionBody, iLFunction);
    if(res < 0)
        return res;

    return 1;
}

namespace 
{
    map<string, string> systemHeadFileMap = {
        pair<string, string>("string.h", "string"),
        pair<string, string>("math.h", "math"),
        pair<string, string>("queue.h", "queue"),
        pair<string, string>("stdio.h", "stdio"),
        pair<string, string>("stdlib.h", "stdlib"),
    };
}

int parseModelFunctionHFile(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile(iLFile->name + ".h");
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);


    string structCode;
    
    size_t pos1 = code.find("typedef struct {");
    while(pos1 != string::npos)
    {
        pos1 += 16;
        size_t pos2 = code.find("}", pos1);
        size_t pos3 = code.find(";", pos2);

        string structContext = code.substr(pos1, pos2 - pos1);
        structContext = stringTrim(structContext);
        structContext = removeStructMemberTypeConst(structContext);

        string structName = code.substr(pos2 + 1, pos3 - pos2 - 1);
        structName = stringTrim(structName);

        structCode += "struct " + structName + "{\n" + structContext + "\n};\n";

        pos1 = code.find("typedef struct {", pos1);

        
        ILTypeDefine* iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = structName;
        iLTypeDef->value = structName;

        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }

    
    vector<string> structStrLine = stringSplit(processStruct(structCode), "\n");
    structStrLine = stringTrimList(structStrLine);
    ILCCodeParser codeParser;
    int iter = ILParser::structTypeList.size();
    codeParser.setExtendDataType(structStrLine);

    iLFile->structDefines.insert(iLFile->structDefines.begin(), ILParser::structTypeList.begin() + iter, ILParser::structTypeList.end());

    
    ILStructDefine* iLStructDefine = new ILStructDefine();
    iLStructDefine->name = "TaskCounters_" + iLFile->name + "_T";
    ILMember* iLMember = new ILMember();
    iLMember->name = "TID";
    iLMember->arraySize.push_back(2);
    iLMember->type = "uint16_T";
    iLStructDefine->members.push_back(iLMember);
    iLFile->structDefines.push_back(iLStructDefine);

    ILTypeDefine* iLTypeDef = new ILTypeDefine();
    iLTypeDef->name = iLStructDefine->name;
    iLTypeDef->value = iLStructDefine->name;

    ILParser::typeDefineTypeList.push_back(iLTypeDef);
    ILParser::allDataTypeList.push_back(iLTypeDef->value);
    iLFile->typeDefines.push_back(iLTypeDef);


    iLStructDefine = new ILStructDefine();
    iLStructDefine->name = "TIME_" + iLFile->name + "_T";
    iLMember = new ILMember();
    iLMember->name = "TaskCounters";
    iLMember->type = "TaskCounters_" + iLFile->name + "_T";
    iLStructDefine->members.push_back(iLMember);
    iLMember = new ILMember();
    iLMember->name = "clockTick0";
    iLMember->type = "uint32_T";
    iLStructDefine->members.push_back(iLMember);
    iLFile->structDefines.push_back(iLStructDefine);

    iLTypeDef = new ILTypeDefine();
    iLTypeDef->name = iLStructDefine->name;
    iLTypeDef->value = iLStructDefine->name;
    
    ILParser::typeDefineTypeList.push_back(iLTypeDef);
    ILParser::allDataTypeList.push_back(iLTypeDef->value);
    iLFile->typeDefines.push_back(iLTypeDef);
    
    if(code.find(" B_" + iLFile->name + "_T") == string::npos)
    {
        iLStructDefine = new ILStructDefine();
        iLStructDefine->name = "B_" + iLFile->name + "_T";
        iLMember = new ILMember();
        iLMember->name = "TempMember";
        iLMember->type = "int";
        iLStructDefine->members.push_back(iLMember);
        iLFile->structDefines.push_back(iLStructDefine);

        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = iLStructDefine->name;
        iLTypeDef->value = iLStructDefine->name;
    }

    iLStructDefine = new ILStructDefine();
    string iLStructDefineNameTemp = "tag_RTM_" + iLFile->name;
    while(code.find(iLStructDefineNameTemp) == string::npos)
    {
        iLStructDefineNameTemp = iLStructDefineNameTemp.substr(0, iLStructDefineNameTemp.length() - 1);
    }
    iLStructDefine->name = iLStructDefineNameTemp + "_T";
    iLMember = new ILMember();
    iLMember->name = "errorStatus";
    iLMember->isAddress = true;
    iLMember->type = "char_T";
    iLStructDefine->members.push_back(iLMember);
    iLMember = new ILMember();
    iLMember->name = "blockIO";
    iLMember->isAddress = true;
    iLMember->type = "B_" + iLFile->name + "_T";
    iLStructDefine->members.push_back(iLMember);
    iLMember = new ILMember();
    iLMember->name = "dwork";
    iLMember->isAddress = true;
    iLMember->type = "DW_" + iLFile->name + "_T";
    iLStructDefine->members.push_back(iLMember);
    iLMember = new ILMember();
    iLMember->name = "Timing";
    iLMember->type = "TIME_" + iLFile->name + "_T";
    iLStructDefine->members.push_back(iLMember);
    iLMember = new ILMember();
    iLMember->name = "prevZCSigState";
    iLMember->type = "PrevZCX_" + ((iLFile->name.length() < (31 - 10)) ? iLFile->name : iLFile->name.substr(0, 31 - 10)) + "_T";
    iLMember->isAddress = 1;
    iLStructDefine->members.push_back(iLMember);
    iLFile->structDefines.push_back(iLStructDefine);


    ILGlobalVariable* iLGlobalVariable = new ILGlobalVariable();
    iLGlobalVariable->name = iLFile->name + "_instance";
    iLGlobalVariable->type = iLStructDefine->name;
    iLFile->globalVariables.push_back(iLGlobalVariable);

    iLGlobalVariable = new ILGlobalVariable();
    iLGlobalVariable->name = iLFile->name + "_DW_instance";
    iLGlobalVariable->type = "DW_" + iLFile->name + "_T";
    iLFile->globalVariables.push_back(iLGlobalVariable);

    iLGlobalVariable = new ILGlobalVariable();
    iLGlobalVariable->name = iLFile->name + "_B_instance";
    iLGlobalVariable->type = "B_" + iLFile->name + "_T";
    iLFile->globalVariables.push_back(iLGlobalVariable);

    iLGlobalVariable = new ILGlobalVariable();
    iLGlobalVariable->name = iLFile->name + "_PrevZCX_instance";
    iLGlobalVariable->type = "PrevZCX_" + ((iLFile->name.length() < (31 - 10)) ? iLFile->name : iLFile->name.substr(0, 31 - 10)) + "_T";
    iLFile->globalVariables.push_back(iLGlobalVariable);

    if(!ILParser::findTypeDefineByValue("DW_" + iLFile->name + "_T"))
    {
        iLStructDefine = new ILStructDefine();
        iLStructDefine->name = "DW_" + iLFile->name + "_T";
        iLMember = new ILMember();
        iLMember->name = "Memory_PreviousInput";
        iLMember->isAddress = false;
        iLMember->type = "real_T";
        iLStructDefine->members.push_back(iLMember);
        iLFile->structDefines.push_back(iLStructDefine);
        ILTypeDefine* iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = iLStructDefine->name;
        iLTypeDef->value = iLStructDefine->name;

        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }


    // To do����ͷ�ļ����Զ�ʶ��
    pos1 = code.find("#include <");
    while(pos1 != string::npos)
    {
        pos1 += 10;
        size_t pos2 = code.find(">", pos1);
        
        string headFileStr = code.substr(pos1, pos2 - pos1);
        if(systemHeadFileMap.find(headFileStr) != systemHeadFileMap.end())
            headFileStr = systemHeadFileMap.at(headFileStr);

        ILHeadFile* iLHeadFile = new ILHeadFile();
        iLHeadFile->name = headFileStr;
        
        iLFile->headFiles.push_back(iLHeadFile);
        
        pos1 = code.find("#include <", pos1);
    }

    {
        ILHeadFile* iLHeadFile = new ILHeadFile();
        iLHeadFile->name = "math";
        iLFile->headFiles.push_back(iLHeadFile);
    }
    {
        ILHeadFile* iLHeadFile = new ILHeadFile();
        iLHeadFile->name = "float";
        iLFile->headFiles.push_back(iLHeadFile);
    }

    string pType = "PrevZCX_" + ((iLFile->name.length() < (31 - 10)) ? iLFile->name : iLFile->name.substr(0, 31 - 10)) + "_T";
    if (ILParser::findTypeDefineByValue(pType) == nullptr)
    {
        ILTypeDefine* iLTypeDef_PrevZCX_t = new ILTypeDefine();
        iLTypeDef_PrevZCX_t->name = "int";
        iLTypeDef_PrevZCX_t->value = pType;
        iLFile->typeDefines.push_back(iLTypeDef_PrevZCX_t);

        ILParser::typeDefineTypeList.push_back(iLTypeDef_PrevZCX_t);
        ILParser::allDataTypeList.push_back(iLTypeDef_PrevZCX_t->value);
    }
    //string externVariable;
    //
    //pos1 = code.find("extern ");
    //while(pos1 != string::npos)
    //{
    //    pos1 += 7;
    //    size_t pos2 = code.find(";", pos1);
    //
    //    string variableContext = code.substr(pos1, pos2 - pos1);
    //    variableContext = stringTrim(variableContext);
    //
    //    string word = getWord(variableContext);
    //    if(word == "void") {
    //        pos1 = code.find("extern ", pos1);
    //        continue;
    //    }
    //    if(word == "const") {
    //        word = getWord(variableContext);
    //    }
    //    bool isAddress = false;
    //    string word1 = getWord(variableContext);
    //    if(word1 == "*") {
    //        isAddress = true;
    //        word1 = getWord(variableContext);
    //    }
    //
    //    ILExternVariable* iLExternVariable = new ILExternVariable();
    //    iLExternVariable->isAddress = isAddress;
    //    iLExternVariable->type = word;
    //    iLExternVariable->name = word1;
    //    iLExternVariable->parent = iLFile;
    //    iLFile->externVariables.push_back(iLExternVariable);
    //
    //
    //    pos1 = code.find("extern ", pos1);
    //}



    return 1;
}


int parseModelFunctionCFile(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile(iLFile->name + ".c");
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);
    size_t pos1 = code.find("void " + iLFile->name + "_step(");
    pos1 += 5 + iLFile->name.length() + 6;
    size_t pos2 = code.find(")", pos1);
    size_t pos3 = code.find("{", pos2) + 1;
    size_t pos4 = pos3;
    int indent = 0;
    while(indent >= 0)
    {
        if(code[pos4] == '{') indent++;
        if(code[pos4] == '}') indent--;
        pos4++;
    }
    pos4--;

    string parameterContext = code.substr(pos1, pos2 - pos1);
    parameterContext = stringTrim(parameterContext);
    string functionContext = code.substr(pos3, pos4 - pos3);
    functionContext = stringTrim(functionContext);

    

    ILFunction* iLFunctionStep = new ILFunction();
    iLFile->functions.push_back(iLFunctionStep);
    iLFunctionStep->name = iLFile->name + "_step";
    iLFunctionStep->type = ILFunction::FunctionExec;
    iLFunctionStep->returnType = "void";

    ILRef* iLRef = new ILRef();
    iLRef->path = iLFile->name;
    iLFunctionStep->refs.push_back(iLRef);

    //ILInput* iLInputStep = new ILInput();
    //iLInputStep->name = "self";
    //iLInputStep->type = iLParser->config.mainCompositeState;
    //iLInputStep->isAddress = true;
    //iLFunctionStep->inputs.push_back(iLInputStep);

    string wordType = getWord(parameterContext);
    while(!wordType.empty())
    {
        bool isAddress = false;
        string wordName = getWord(parameterContext);
        if(wordName == "*") {
            isAddress = true;
            wordName = getWord(parameterContext);
        }
        if(wordName == "const")
        {
            wordName = getWord(parameterContext);
        }

        vector<int> arraySize;

        string word = getWord(parameterContext);
        while(word == "[")
        {
            word = getWord(parameterContext);
            arraySize.push_back(stringToInt(word));
            word = getWord(parameterContext);
            word = getWord(parameterContext);
        }

        if(isAddress && iLFunctionStep->inputs.size() >= 1)
        {
            ILOutput* iLOutput_p = new ILOutput();
            iLOutput_p->name = wordName;
            iLOutput_p->type = wordType;
            iLOutput_p->isAddress = false;
            iLOutput_p->arraySize = arraySize;
            iLFunctionStep->outputs.push_back(iLOutput_p);
        }
        else
        {
            ILInput* iLInput_p = new ILInput();
            iLInput_p->name = wordName;
            iLInput_p->type = wordType;
            iLInput_p->isAddress = isAddress;
            iLInput_p->arraySize = arraySize;
            iLFunctionStep->inputs.push_back(iLInput_p);

            if(iLFunctionStep->inputs.size() == 1)
            {
                iLParser->config.mainCompositeState = wordType;
            }
        }
        //wordType = getWord(parameterContext);
        wordType = getWord(parameterContext);
    }
    
    ILSchedule* iLScheduleStep = new ILSchedule();
    iLFunctionStep->schedule = iLScheduleStep;

    ILCCodeParser codeParser;
    Statement stepStmt;
    int res = codeParser.parseCCode(functionContext, &stepStmt);
    if(res < 0)
    {
        return res;
    }

    ILCalculate* iLCalculateStep = new ILCalculate();
    iLCalculateStep->statements = stepStmt;
    iLCalculateStep->name = iLFile->name + "_step";

    iLScheduleStep->scheduleNodes.push_back(iLCalculateStep);






    pos1 = code.find("void " + iLFile->name + "_initialize(");
    pos1 += 5 + iLFile->name.length() + 12;
    pos2 = code.find(")", pos1);
    pos3 = code.find("{", pos2) + 1;
    pos4 = pos3;
    indent = 0;
    while(indent >= 0)
    {
        if(code[pos4] == '{') indent++;
        if(code[pos4] == '}') indent--;
        pos4++;
    }
    pos4--;

    parameterContext = code.substr(pos1, pos2 - pos1);
    parameterContext = stringTrim(parameterContext);

    functionContext = code.substr(pos3, pos4 - pos3);
    functionContext = stringTrim(functionContext);

    ILFunction* iLFunctionInit = new ILFunction();
    iLFile->functions.push_back(iLFunctionInit);
    iLFunctionInit->name = iLFile->name + "_init";
    iLFunctionInit->type = ILFunction::FunctionInit;
    iLFunctionInit->returnType = "void";
    
    iLRef = new ILRef();
    iLRef->path = iLFile->name;
    iLFunctionInit->refs.push_back(iLRef);

    //ILInput* iLInputInit = new ILInput();
    //iLInputInit->name = "self";
    //iLInputInit->type = iLParser->config.mainCompositeState;
    //iLInputInit->isAddress = true;
    //iLInputInit->arraySize.push_back(9);
    //iLFunctionInit->inputs.push_back(iLInputInit);

    
    wordType = getWord(parameterContext);
    while(!wordType.empty())
    {
        bool isAddress = false;
        string word1 = getWord(parameterContext);
        if(word1 == "*") {
            isAddress = true;
            word1 = getWord(parameterContext);
        }
        if(word1 == "const")
        {
            word1 = getWord(parameterContext);
        }
        
        vector<int> arraySize;

        string word = getWord(parameterContext);
        while(word == "[")
        {
            word = getWord(parameterContext);
            arraySize.push_back(stringToInt(word));
            word = getWord(parameterContext);
            word = getWord(parameterContext);
        }

        if(isAddress && iLFunctionInit->inputs.size() >= 1)
        {
            ILOutput* iLOutput_p = new ILOutput();
            iLOutput_p->name = word1;
            iLOutput_p->type = wordType;
            iLOutput_p->isAddress = false;
            iLOutput_p->arraySize = arraySize;
            iLFunctionInit->outputs.push_back(iLOutput_p);
        }
        else
        {
            ILInput* iLInput_p = new ILInput();
            iLInput_p->name = word1;
            iLInput_p->type = wordType;
            iLInput_p->isAddress = isAddress;
            iLInput_p->arraySize = arraySize;
            iLFunctionInit->inputs.push_back(iLInput_p);
        }
        //wordType = getWord(parameterContext);
        wordType = getWord(parameterContext);
    }




    ILSchedule* iLScheduleInit = new ILSchedule();
    iLFunctionInit->schedule = iLScheduleInit;

    
    Statement initStmt;
    ILCCodeParser codeParserInit;
    functionContext = iLFunctionInit->inputs[0]->name + "->prevZCSigState = &" + iLFile->name + "_PrevZCX_instance;\n" + functionContext;
    functionContext = iLFunctionInit->inputs[0]->name + "->dwork = &" + iLFile->name + "_DW_instance;\n" + functionContext;
    functionContext = iLFunctionInit->inputs[0]->name + "->blockIO = &" + iLFile->name + "_B_instance;\n" + functionContext;
    functionContext = "(void)memset((void*)" + iLFunctionInit->inputs[0]->name + ", 0, sizeof(" + iLFunctionInit->inputs[0]->type + "));\n" + functionContext;
    res = codeParserInit.parseCCode(functionContext, &initStmt);
    if(res < 0)
    {
        return res;
    }

    ILCalculate* iLCalculateInit = new ILCalculate();
    iLCalculateInit->statements = initStmt;
    iLCalculateInit->name = iLFile->name + "_init";

    iLScheduleInit->scheduleNodes.push_back(iLCalculateInit);




    SLCCodeParser slcparser;
    slcparser.parse(iLFile->name + ".c");

    if(slcparser.functions.empty())
        return 1;
    
    for(int j = 0; j < slcparser.functions.size(); j++)
    {
        string functionStr = slcparser.functions[j];
        if(stringStartsWith(functionStr, "void " + iLFile->name + "_initialize(") ||
            stringStartsWith(functionStr, "void " + iLFile->name + "_step(") ||
            stringStartsWith(functionStr, "void " + iLFile->name + "_terminate("))
            continue;

        res = parseOtherFileFunction(iLParser, iLFile, functionStr);
        if(res < 0)
            return res;
    }


    return 1;
}

int parseModelFunctionCFileDefine(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile(iLFile->name + ".c");
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);

    if (code.empty())
        return 0;
    code = codeRemoveDoubleBlank(code);

    vector<string> codeLines = stringSplit(code, "\n");
    for (int i = 0; i < codeLines.size(); i++)
    {
        if (codeLines[i].empty())
            continue;
        vector<string> sp = stringSplit(codeLines[i], " ");
        if (sp.size() == 3 && sp[0] == "#define")
        {
            ILMacro* iLMacro = new ILMacro();
            iLMacro->name = sp[1];
            iLMacro->value = sp[2];

            iLFile->macros.push_back(iLMacro);
        }
    }
    return 1;
}

int parseModelPrivate(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile(iLFile->name + "_private.h");
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);

    if (code.empty())
        return 0;
    code = codeRemoveDoubleBlank(code);

    vector<string> codeLines = stringSplit(code, "\n");
    for (int i = 0; i < codeLines.size(); i++)
    {
        if (codeLines[i].empty())
            continue;
        vector<string> sp = stringSplit(codeLines[i], " ");
        if (sp.size() == 3 && sp[0] == "extern")
        {
            ILConfigParameter p;
            p.name = sp[2];
            if(stringEndsWith(p.name, ";"))
                p.name = p.name.substr(0, p.name.length() - 1);

            p.type = sp[1];
            iLParser->config.parameters.push_back(p);

            ILGlobalVariable* iLGlobalVariable = new ILGlobalVariable();
            iLGlobalVariable->name = p.name;
            iLGlobalVariable->type = p.type;
            iLFile->globalVariables.push_back(iLGlobalVariable);

        }
    }
    return 1;
}

int parseModelTypesFile(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile(iLFile->name + "_types.h");
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);

    size_t pos1 = code.find("typedef ");
    while(pos1 != string::npos)
    {
        pos1 += 8;
        size_t pos2 = code.find(";", pos1);

        string typedefContext = code.substr(pos1, pos2 - pos1);
        typedefContext = stringTrim(typedefContext);

        bool isStruct = false;
        string word = getWord(typedefContext);

        if(word == "struct")
        {
            isStruct = true;
            word = getWord(typedefContext);
        }

        string word1 = getWord(typedefContext);

        ILTypeDefine* iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = word;
        iLTypeDef->value = word1;

        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);

        pos1 = code.find("typedef ", pos1);
    }

    return 1;
}

int parseRTWTypesFile(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile("rtwtypes.h");
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);

    string structCode;

    //if(code.find("size_t") == string::npos)
    //    code = "typedef int size_t;\n" + code;

    size_t pos1 = code.find("typedef ");
    while(pos1 != string::npos)
    {
        size_t pos9 = code.find(";", pos1);

        string typedefContext = code.substr(pos1, pos9 - pos1);
        typedefContext = stringTrim(typedefContext);

        //�ǽṹ���typedef
        if(typedefContext.find("{") != string::npos) {
            pos1 += 16;
            size_t pos2 = code.find("}", pos1);
            size_t pos3 = code.find(";", pos2);

            string structContext = code.substr(pos1, pos2 - pos1);
            structContext = stringTrim(structContext);

            string structName = code.substr(pos2 + 1, pos3 - pos2 - 1);
            structName = stringTrim(structName);

            structCode += "struct " + structName + "{\n" + structContext + "\n};\n";

            ILTypeDefine* iLTypeDef = new ILTypeDefine();
            iLTypeDef->name = structName;
            iLTypeDef->value = structName;

            ILParser::typeDefineTypeList.push_back(iLTypeDef);
            ILParser::allDataTypeList.push_back(iLTypeDef->value);
            iLFile->typeDefines.push_back(iLTypeDef);
        }
        else//����ͨ���͵�typedef
        {
            pos1 += 8;
            size_t pos2 = typedefContext.rfind(" ");
            string word = typedefContext.substr(8, pos2 - 8);
            string word1 = typedefContext.substr(pos2 + 1, typedefContext.length() - pos2 - 1);

            ILTypeDefine* iLTypeDef = new ILTypeDefine();
            iLTypeDef->name = word;
            iLTypeDef->value = word1;

            ILParser::typeDefineTypeList.push_back(iLTypeDef);
            ILParser::allDataTypeList.push_back(iLTypeDef->value);
            iLFile->typeDefines.push_back(iLTypeDef);
        }
        
        pos1 = code.find("typedef ", pos1);
    }

    ILTypeDefine* iLTypeDef_size_t = new ILTypeDefine();
    iLTypeDef_size_t->name = "int";
    iLTypeDef_size_t->value = "size_t";

    ILParser::typeDefineTypeList.push_back(iLTypeDef_size_t);
    ILParser::allDataTypeList.push_back(iLTypeDef_size_t->value);

    vector<string> structStrLine = stringSplit(processStruct(structCode), "\n");
    structStrLine = stringTrimList(structStrLine);
    ILCCodeParser codeParser;
    int iter = ILParser::structTypeList.size();
    codeParser.setExtendDataType(structStrLine);


    iLFile->structDefines.insert(iLFile->structDefines.begin(), ILParser::structTypeList.begin() + iter, ILParser::structTypeList.end());


    ILMacro* iLMacro = new ILMacro();
    iLMacro->name = "false";
    iLMacro->value = "0";
    iLFile->macros.push_back(iLMacro);
    iLMacro = new ILMacro();
    iLMacro->name = "true";
    iLMacro->value = "1";
    iLFile->macros.push_back(iLMacro);
    iLMacro = new ILMacro();
    iLMacro->name = "NULL";
    iLMacro->value = "0";
    iLFile->macros.push_back(iLMacro);
    iLMacro = new ILMacro();
    iLMacro->name = "UNUSED_PARAMETER(x)";
    iLMacro->value = "(void)(x)";
    iLFile->macros.push_back(iLMacro);
    iLMacro = new ILMacro();
    iLMacro->name = "rtmGetErrorStatus(rtm)";
    iLMacro->value = "((rtm)->errorStatus)";
    iLFile->macros.push_back(iLMacro);
    iLMacro = new ILMacro();
    iLMacro->name = "rtmSetErrorStatus(rtm,val)";
    iLMacro->value = "((rtm)->errorStatus=(val))";
    iLFile->macros.push_back(iLMacro);
    iLMacro = new ILMacro();
    iLMacro->name = "POS_ZCSIG";
    iLMacro->value = "1";
    iLFile->macros.push_back(iLMacro);
    


    ILTypeDefine* iLTypeDef = nullptr;

    if(!ILParser::findTypeDefineByValue("int_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "int";
        iLTypeDef->value = "int_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("real_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "float";
        iLTypeDef->value = "real_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("real32_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "float";
        iLTypeDef->value = "real32_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("boolean_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "char";
        iLTypeDef->value = "boolean_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("uint32_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "unsigned int";
        iLTypeDef->value = "uint32_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("uint8_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "unsigned char";
        iLTypeDef->value = "uint8_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("ZCEventType"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "int";
        iLTypeDef->value = "ZCEventType";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("_ssMdlInfo"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "struct _ssMdlInfo";
        iLTypeDef->value = "_ssMdlInfo";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        ILParser::allDataTypeList.push_back(iLTypeDef->name);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if(!ILParser::findTypeDefineByValue("time_T"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "int";
        iLTypeDef->value = "time_T";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }
    if (!ILParser::findTypeDefineByValue("ZCSigState"))
    {
        iLTypeDef = new ILTypeDefine();
        iLTypeDef->name = "uint8_T";
        iLTypeDef->value = "ZCSigState";
        ILParser::typeDefineTypeList.push_back(iLTypeDef);
        ILParser::allDataTypeList.push_back(iLTypeDef->value);
        iLFile->typeDefines.push_back(iLTypeDef);
    }


    code = codeRemoveDoubleBlank(code);
    vector<string> codeLines = stringSplit(code, "\n");
    for (int i = 0; i < codeLines.size(); i++)
    {
        if (codeLines[i].empty())
            continue;
        vector<string> sp = stringSplit(codeLines[i], " ");
        if (sp.size() == 3 && sp[0] == "#define")
        {
            if (sp[1] == "true" || sp[1] == "false")
                continue;

            ILMacro* iLMacro = new ILMacro();
            iLMacro->name = sp[1];
            iLMacro->value = sp[2];

            iLFile->macros.push_back(iLMacro);
        }
    }

    return 1;
}

int parseRTDefineFile(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile("rt_defines.h");
    if(code.empty())
        return 0;
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);
    code = codeRemoveDoubleBlank(code);

    vector<string> codeLines = stringSplit(code, "\n");
    for(int i = 0; i < codeLines.size(); i++)
    {
        if(codeLines[i].empty())
            continue;
        vector<string> sp = stringSplit(codeLines[i], " ");
        if(sp.size() == 3 && sp[0] == "#define")
        {
            ILMacro* iLMacro = new ILMacro();
            iLMacro->name = sp[1];
            iLMacro->value = sp[2];
            
            iLFile->macros.push_back(iLMacro);
        }
    }
    return 1;
}

int parseModelDataFile(ILParser* iLParser, ILFile* iLFile)
{
    string code = readFile(modelName + "_data.c");
    if(code.empty())
        return 0;
    code = codeRemoveComment(code);
    code = codeTrimAllLines(code);
    code = codeRemoveDoubleBlank(code);

    size_t pos1 = code.find("const ");
    while(pos1 != string::npos)
    {
        pos1 += 6;
        size_t pos2 = code.find(";", pos1);
        
        string varContext = code.substr(pos1, pos2 - pos1);
        varContext = stringTrim(varContext);
        varContext = stringReplaceAll(varContext, "\n", "");

        string wordType = getWord(varContext);
        bool isAddress = false;
        string wordName = getWord(varContext);
        if(wordName == "*")
        {
            isAddress = true;
            wordName = getWord(varContext);
        }
        vector<int> arraySize;

        string word = getWord(varContext);
        while(word == "[")
        {
            word = getWord(varContext);
            arraySize.push_back(stringToInt(word));
            word = getWord(varContext);
            word = getWord(varContext);
        }
        string valueStr;
        if(word == "=")
        {
            valueStr = stringTrim(varContext);
        }

        ILGlobalVariable* iLGlobalVariable = new ILGlobalVariable();
        iLGlobalVariable->name = wordName;
        iLGlobalVariable->type = wordType;
        iLGlobalVariable->arraySize = arraySize;
        iLGlobalVariable->isAddress = isAddress;
        string expressionStr = "v=" + valueStr;
        Expression* tempExp = nullptr;
        ILExpressionParser expressionParser;
        int res = expressionParser.parseExpression(expressionStr, &tempExp);
        if(res < 0)
	        return res;
        iLGlobalVariable->defaultValue = tempExp->childExpressions[1]->clone();
        tempExp->release();
        delete tempExp;

        iLFile->globalVariables.push_back(iLGlobalVariable);

        pos1 = code.find("const ", pos1);
    }
    return 1;
}


int main(int argc, char** argv)
{

    if(argc < 2)
    {
        cout << "Model code not found.\n";
        return 0;
    }

    string modelNameTemp = string(argv[1]);
    if(!isFileExist(modelNameTemp + ".c"))
    {
        cout << "Model code not found.\n";
        return 0;
    }

    modelName = modelNameTemp;

    int res = 0;

    ILParser iLParser;

    iLParser.config.iterationCount = 10000;
    iLParser.config.mainExecFunction = modelName + "_step";
    iLParser.config.mainInitFunction = modelName + "_init";
    iLParser.config.mainCompositeState = "RT_MODEL_" + modelName + "_T";



    ILFile* iLFile = new ILFile();
    iLParser.files.push_back(iLFile);
    iLFile->name = modelName;

    res = parseRTDefineFile(&iLParser, iLFile);
    if(res < 0)
        return res;

    res = parseRTWTypesFile(&iLParser, iLFile);
    if(res < 0)
        return res;

    res = parseModelPrivate(&iLParser, iLFile);
    if (res < 0)
        return res;

    res = parseModelTypesFile(&iLParser, iLFile);
    if(res < 0)
        return res;

    res = parseModelFunctionHFile(&iLParser, iLFile);
    if(res < 0)
        return res;

    res = parseModelFunctionCFile(&iLParser, iLFile);
    if(res < 0)
        return res;

    res = parseModelFunctionCFileDefine(&iLParser, iLFile);
    if (res < 0)
        return res;

    ILFile* iLFileData = new ILFile();
    iLParser.files.push_back(iLFileData);
    iLFileData->name = modelName + "_data";
    res = parseModelDataFile(&iLParser, iLFileData);
    if(res < 0)
        return res;
    
    
    vector<string> fileLists;
    listFiles(".", fileLists, ".c");
    for(int i = 0; i < fileLists.size(); i++)
    {
        string filePath = fileLists[i];
        if(stringEndsWith(filePath, modelName + ".c") || 
            stringEndsWith(filePath, modelName + ".h") || 
            stringEndsWith(filePath, modelName + "_data.c") || 
            stringEndsWith(filePath, modelName + "_private.h") || 
            stringEndsWith(filePath, modelName + "_types.h") || 
            stringEndsWith(filePath, "ert_main.c") || 
            stringEndsWith(filePath, "rtwtypes.h") || 
            stringEndsWith(filePath, "rt_defines.h"))
            continue;

        SLCCodeParser slcparser;
        slcparser.parse(filePath);

        if(slcparser.functions.empty())
            continue;

        ILFile* iLFileOther = new ILFile();
        iLParser.files.push_back(iLFileOther);
        iLFileOther->name = getFileNameWithoutSuffixByPath(filePath);

        for(int j = 0; j < slcparser.functions.size(); j++)
        {
            res = parseOtherFileFunction(&iLParser, iLFileOther, slcparser.functions[j]);
            if(res < 0)
                return res;
        }
        

    }


    ILSaver iLSaver;
    iLSaver.save(&iLParser, modelName + ".xml");



    iLParser.release();

    cout << "Done!\n";

    return 1;
}
