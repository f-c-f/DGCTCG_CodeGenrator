#include "SLCCodeParser.h"
#include "../../Src/Common/Utility.h"
#include <iostream>
#include <string>

#include "util.h"


struct CheckNode
{
    string name;
    string kindType;
    string file;
    unsigned int line;
    unsigned int column;
    unsigned int offset;
    
    unsigned int line_e;
    unsigned int column_e;
    unsigned int offset_e;
    unsigned int line_s;
    unsigned int column_s;
    unsigned int offset_s;
    CXCursor cursor;

    string ref_name;
    string ref_kindType;
    string ref_file;
    unsigned int ref_line;
    unsigned int ref_column;
    unsigned int ref_offset;

};

CheckNode getCheckNode(CXCursor cursor)
{
    CXFile file;
    unsigned int line, column, offset;
    unsigned int line_e, column_e, offset_e;
    unsigned int line_s, column_s, offset_s;

    CXString text = clang_getCursorSpelling(cursor);
    string textStr;
    if (clang_getCString (text)) {
      textStr = string(clang_getCString (text));
    }
    clang_disposeString (text);

    CXString kind = clang_getCursorKindSpelling(clang_getCursorKind(cursor));
    string kindStr;
    if (clang_getCString (kind)) {
      kindStr = string(clang_getCString (kind));
    }
    clang_disposeString (kind);
    
    clang_getExpansionLocation (clang_getCursorLocation (cursor), &file, &line, &column, &offset);
    CXSourceRange range = clang_getCursorExtent(cursor);

    clang_getExpansionLocation (clang_getRangeEnd (range), &file, &line_e, &column_e, &offset_e);
    clang_getExpansionLocation (clang_getRangeStart (range), &file, &line_s, &column_s, &offset_s);

    
    CXString fileName = clang_getFileName (file);
    string canonicalPath;
    if (clang_getCString (fileName)) {
      canonicalPath = string(clang_getCString (fileName));
    }
    clang_disposeString (fileName);

    CheckNode ret;
    ret.file = canonicalPath;
    ret.offset = offset;
    ret.column = column;
    ret.line = line;
    ret.offset_e = offset_e;
    ret.column_e = column_e;
    ret.line_e = line_e;
    ret.offset_s = offset_s;
    ret.column_s = column_s;
    ret.line_s = line_s;
    ret.name = textStr;
    ret.kindType = kindStr;
    ret.cursor = cursor;
    return ret;
}

string currentFilePath;
string currentFileStr;
CXCursor cursorRoot;

bool isCursorSame(CXCursor &a, CXCursor &b)
{
    if(a.data == a.data && a.kind == a.kind && a.xdata == a.xdata)
        return true;
    return false;
}

vector<string> tempFunctions;

int state = 0;
// 1�����ҵ�������������Ҫ�ҷ���ֵ����
int functionEndOffset = -1;
int functionStartOffset = -1;

CXChildVisitResult visitChildren(CXCursor c, CXCursor parent, CXClientData client_data)
{

    CheckNode checkNode = getCheckNode(c);
    if(checkNode.file != currentFilePath)
    {
        return CXChildVisit_Continue;
    }
    
    //cout << "L:" << checkNode.line_s << " C:" << checkNode.column_s << "\t"
    //    << "L:" << checkNode.line_e << " C:" << checkNode.column_e << "\t Cursor '" << checkNode.name << "' of kind '"
    //    << checkNode.kindType << "'\n";

    if(checkNode.kindType == "FunctionDecl" && isCursorSame(parent, cursorRoot))
    {
        tempFunctions.push_back(currentFileStr.substr(checkNode.offset_s, checkNode.offset_e-checkNode.offset_s));
    }


    return CXChildVisit_Recurse;
}


int SLCCodeParser::parse(string filePath)
{
    state = 0;
    tempFunctions.clear();
    //cout << filePath << endl;
    currentFilePath = filePath;
    currentFileStr = readFileOri(filePath);
    CXIndex index = clang_createIndex(0, 0);
    string includeStr = readFile(getExeDirPath() + "/include.txt");
    vector<string> includeLine = stringSplit(includeStr, "\n");
    vector<string> includePaths;
    for(int i = 0; i < includeLine.size(); i++)
    {
        includeLine[i] = stringTrim(includeLine[i]);
        if(!includeLine[i].empty())
            includePaths.push_back("-I" + includeLine[i]);
    }
    includePaths.insert(includePaths.begin(), "clang++");
    char** args = new char*[includePaths.size()];
    for(int i = 0; i < includePaths.size(); i++)
    {
        args[i] = new char[includePaths[i].length() + 1];
        strcpy_s(args[i],includePaths[i].length() + 1,includePaths[i].c_str());
    }
    CXTranslationUnit unit;
    enum CXErrorCode Result = clang_parseTranslationUnit2FullArgv(
        index,
        filePath.c_str(),
        args, 
        includePaths.size(), 
        nullptr, 
        0,
        CXTranslationUnit_None, &unit);

    cursorRoot = clang_getTranslationUnitCursor(unit);
    clang_visitChildren(cursorRoot, visitChildren, nullptr);

    clang_disposeTranslationUnit(unit);
    clang_disposeIndex(index);

    functions = tempFunctions;

    return 1;
}
