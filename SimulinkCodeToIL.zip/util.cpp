#include "util.h"
#include <string>
#include <vector>
#include <io.h> //_access fun
#include <direct.h> //_mkdir fun
#include <fstream>
#include <sstream>
#include <windows.h>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <iostream>
#include <set>


#include "../../Src/Common/Utility.h"

using namespace std;

int process(std::string& typeStr, int curPos)
{
	while (curPos < typeStr.length())
	{
		char c = typeStr[curPos];
		if (c == '\n')
		{
			typeStr.replace(curPos, 1, 1,' ');
			curPos++;
		}
		else if (c == '}')
		{
			return curPos+1;
		}
		else if (c == '{')
		{
			curPos = process(typeStr, curPos+1);
		}
		else {
			curPos++;
		}
	}
	return curPos;
}

std::string processStruct(std::string str)
{
	std::string typeStr = str;
	int index = 0;
	while (index < typeStr.length())
	{
		char c = typeStr[index];
		if (c == '{')
		{
			index=process(typeStr, index+1);
		}
		index++;
	}
	return typeStr;
}


std::string getWord(std::string& code)
{
    code = stringTrim(code);
    string ret;
    int i = 0;
    bool symbol = false;
    while(i < code.length())
    {
        if(code[i] == ' ')
            break;
        
        if(code[i] >= '0' && code[i] <= '9' || code[i] >= 'a' && code[i] <= 'z' || code[i] >= 'A' && code[i] <= 'Z' || code[i] == '_')
        {
            ret += code[i];
            i++;
        }
        else
        {
            if(ret.empty())
            {
                ret += code[i];
                i++;
            }
            
            break;
        }
    }
    code = code.substr(i, code.length() - i);
    return ret;
}



void listFiles(string dir, vector<string> &fileList, string format)
{
    if(stringEndsWith(dir, "\\"))
        dir = dir.substr(0, dir.length() - 1);

	char dirNew[200];
	strcpy(dirNew, dir.c_str());
	strcat(dirNew, "\\*.*");
	
	intptr_t handle;
	_finddata_t findData;
	
	handle = _findfirst(dirNew, &findData);
	if (handle == -1)
		return;
	do
	{
		if (findData.attrib & _A_SUBDIR)
		{
			if (strcmp(findData.name, ".") == 0 || strcmp(findData.name, "..") == 0)
				continue;
			
			//strcpy(dirNew, dir.c_str());
			//strcat(dirNew, "\\");
			//strcat(dirNew, findData.name);
			//string pathNew(dirNew);
			//listFiles(pathNew, fileList,format);
		}
		else
		{
			string fileDir(dir);
			fileDir+= "\\";
			fileDir+=findData.name;

            if(format.empty())
                fileList.push_back(fileDir);
            else
            {
                vector<string> formatList = stringSplit(format, ",");
                for(int i = 0; i < formatList.size(); i++)
                {
			        if(fileDir.substr(fileDir.length()-formatList[i].length(),formatList[i].length()) == formatList[i])
				        fileList.push_back(fileDir);
                }
            }
		}
	
	} while (_findnext(handle, &findData) == 0);
	
	_findclose(handle);

}


string readFileOri(string path)
{
    string ret;
	ifstream file;
	file.open(path, ios::binary);
    char c;
    file >> noskipws;
    while (!file.eof())
    {
        file>>c;
        ret += c;
    }
    
    file.close();
	return ret;
}

string removeCodeIfdef(string code)
{
    string codeRet = code;

    size_t pos = codeRet.find("#ifdef");
    while(pos != string::npos)
    {
        size_t pos2 = codeRet.find("#endif", pos);
        size_t pos3 = codeRet.find("#else", pos);

        if(pos3 == string::npos || pos3 > pos2) // û��#else
        {
            codeRet = codeRet.replace(pos, pos2 + 6 - pos, "");
        }
        else // ��#else
        {
            codeRet = codeRet.replace(pos2, 6, "");
            codeRet = codeRet.replace(pos, pos3 + 5 - pos, "");
        }
        pos = codeRet.find("#ifdef");
    }

    pos = codeRet.find("#ifndef");
    while(pos != string::npos)
    {
        size_t pos2 = codeRet.find("#endif", pos);
        size_t pos3 = codeRet.find("#else", pos);

        if(pos3 == string::npos || pos3 > pos2) // û��#else
        {
            codeRet = codeRet.replace(pos2, 6, "");
            codeRet = codeRet.replace(pos, 7, "");
        }
        else // ��#else
        {
            codeRet = codeRet.replace(pos3, pos2 + 6 - pos3, "");
            codeRet = codeRet.replace(pos, 7, "");
        }
        pos = codeRet.find("#ifndef");
    }
    
    return codeRet;
}

string removeStructMemberTypeConst(string code)
{
    vector<string> codeLines = stringSplit(code, "\n");
    codeLines = stringTrimList(codeLines);
    string ret;
    for(int i = 0; i < codeLines.size(); i++)
    {
        if(stringStartsWith(codeLines[i], "const "))
        {
            ret += codeLines[i].substr(6, codeLines[i].length() - 6) + "\n";
        }
        else
        {
            ret += codeLines[i] + "\n";
        }
    }
    return stringTrim(ret);
}
